# -*- coding: utf-8 -*-
"""
Created on Tue Nov 22 10:03:56 2022

@author: amber
"""

import streamlit as st
import pandas as pd
import numpy as np
import pickle as pkle
import os.path

st.set_page_config(
    page_title = "Multipage App",
)


st.title('Uploaden data')
st.session_state.omloopplanning = st.file_uploader('Kies het bestand met de omloopplanning', type= 'xlsx')
st.session_state.datafile = st.file_uploader('Kies het bestand met de data', type= 'xlsx')

keuzes = {'Upload eerst de bovenstaande bestanden'}

col1, = st.columns(1)
with st.form("Capaciteit bus"):
   st.write("Tot hoeveel procent zijn de accus momenteel opgeladen?")
   st.session_state.percentage_opgeladen = st.slider('capaciteit bussen (in %)')
   percentage_opgeladen = st.form_submit_button("Submit")
   if st.session_state.percentage_opgeladen:
       st.write("opgeslagen")

if st.session_state.omloopplanning and st.session_state.datafile:
    st.markdown('---')
    df1 = pd.read_excel(st.session_state.omloopplanning, engine='openpyxl')
    df2 = pd.read_excel(st.session_state.datafile, engine='openpyxl')
    keuzes = set(df1['startlocatie'])

with col1:
    radio = st.radio(
        "Hoe wordt het oplaadstation genoemd?",
        keuzes,
    )
    st.session_state.garagenaam = radio








# if st.session_state.omloopplanning:
#     df = pd.read_excel(st.session_state.omloopplanning)
#     st.dataframe(df)

# if st.session_state.tweede:
#     df = pd.read_excel(st.session_state.tweede)
#     st.dataframe(df)


