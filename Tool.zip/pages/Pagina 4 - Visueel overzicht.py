# -*- coding: utf-8 -*-
import streamlit as st
import pandas as pd
import plotly.express as px
import datetime
import matplotlib.pyplot as plt
import altair as alt
import numpy as np

st.header('Pie chart Eisen')
labels_eisen = 'Eis 1', 'Eis 2', 'Eis 3','Eis 4','Eis 5','Eis 6','Eis 7','Eis 8','Eis 9'
sizes_eisen = [st.session_state.counter1, 
               st.session_state.counter2, 
               st.session_state.counter3, 
               st.session_state.counter4, 
               st.session_state.counter5, 
               st.session_state.counter6, 
               st.session_state.counter7, 
               st.session_state.counter8, 
               st.session_state.counter9]

# fig1, ax1 = plt.subplots()
# ax1.pie(sizes, labels=labels, autopct='%1.1f%%',
#     shadow=True, startangle=90)
# ax1.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

fig_eisen = px.pie(values=sizes_eisen, names = labels_eisen, title = 'Eisen')
st.plotly_chart(fig_eisen)

############################# FICTIEVE WAARDE
counter1w = 2*st.session_state.waarde_wens1
counter2w = 3*st.session_state.waarde_wens2
counter3w = 5*st.session_state.waarde_wens3
#############################

# Pie chart Wensen met totaal aantal counters
st.subheader('Pie chart Wensen')
labels_wensen = 'Wens 1', 'Wens 2', 'Wens 3'
sizes_wensen = [counter1w, counter2w, counter3w]

fig_wensen = px.pie(values=sizes_wensen, names = labels_wensen, title = 'Wensen')
st.plotly_chart(fig_wensen)