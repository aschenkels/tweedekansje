# -*- coding: utf-8 -*-

import streamlit as st
import pandas as pd

df2 = pd.read_excel('C:/Users/amber/OneDrive - Office 365 Fontys/Fontys/LEERJAAR 2/Project 6/Week 2/Omloop planning.xlsx')
df1 = pd.read_excel('C:/Users/amber/OneDrive - Office 365 Fontys/Fontys/LEERJAAR 2/Project 6/Week 2/Connexxion data - 2022-2023.xlsx') 
counter2 = 0
verkeerde_ritten = []
for k in range(len(df2['startlocatie'])-1):
    j = k + 1
    if df2['startlocatie'][j] != df2['eindlocatie'][k]:
        counter2 += 1
        verkeerde_ritten.append(df2['startlocatie'], df2['eindlocatie'][k], df2['omloop nummer'][j])

st.session_state.verkeerde_ritten = verkeerde_ritten
st.write(st.session_state.verkeerde_ritten)